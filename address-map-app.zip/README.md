# Address Map App

A small Node.js app for validating submitted addresses with Google's Address Validation API, displaying the validated result on Google Maps, and storing submissions in a local SQLite database.

## Important

This application does **not** create or force a private address into Google's public Maps database. It validates and displays addresses in your own application. Public Google Maps data is controlled by Google and its contribution/review systems.

## Requirements

- Node.js 20+ recommended
- A Google Cloud project
- Billing enabled for the Google Maps Platform APIs you use
- A Google Maps Platform API key

## Google Cloud setup

Enable the APIs needed by this project, including:

- Maps JavaScript API
- Address Validation API

Create an API key and restrict it appropriately.

For production, use separate browser/server credentials where appropriate and restrict keys by API, domain, IP, or other Google-supported controls.

## Install

```bash
npm install
```

Copy `.env.example` to `.env` and fill in:

```env
PORT=3000
GOOGLE_MAPS_API_KEY=YOUR_GOOGLE_MAPS_API_KEY
ADMIN_TOKEN=use-a-long-random-secret
```

Start:

```bash
npm start
```

Open:

http://localhost:3000

Admin page:

http://localhost:3000/admin.html

The admin API requires the `ADMIN_TOKEN` header. The included admin page asks for it.

## API

### POST /api/validate

Body:

```json
{
  "addressLines": [
    "Via Sant'Anna 8",
    "95124 Catania"
  ],
  "regionCode": "IT"
}
```

### GET /api/submissions

Requires:

```text
x-admin-token: YOUR_ADMIN_TOKEN
```

### POST /api/submissions

Stores a validated submission.

## Security notes

Do not commit `.env`.

For production, put the app behind HTTPS, add real authentication/authorization, rate limiting, CSRF protection where applicable, input limits, logging, and a production database. Do not expose a server-side Google API key in browser JavaScript.
