require("dotenv").config();

const express = require("express");
const path = require("path");
const Database = require("better-sqlite3");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const GOOGLE_KEY = process.env.GOOGLE_MAPS_API_KEY;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN;

if (!GOOGLE_KEY) {
  console.warn("GOOGLE_MAPS_API_KEY is not configured.");
}
if (!ADMIN_TOKEN) {
  console.warn("ADMIN_TOKEN is not configured. Admin API requests will be rejected.");
}

const db = new Database(path.join(__dirname, "data", "addresses.db"));

db.exec(`
  CREATE TABLE IF NOT EXISTS submissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    submitted_at TEXT NOT NULL DEFAULT (datetime('now')),
    address_input TEXT NOT NULL,
    formatted_address TEXT,
    latitude REAL,
    longitude REAL,
    place_id TEXT,
    validation_status TEXT,
    raw_json TEXT
  )
`);

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

function requireAdmin(req, res, next) {
  if (!ADMIN_TOKEN || req.get("x-admin-token") !== ADMIN_TOKEN) {
    return res.status(401).json({ error: "Unauthorized" });
  }
  next();
}

app.get("/api/config", (req, res) => {
  res.json({
    mapsBrowserKey: GOOGLE_KEY || null
  });
});

app.post("/api/validate", async (req, res) => {
  try {
    if (!GOOGLE_KEY) {
      return res.status(500).json({ error: "Google API key is not configured on the server." });
    }

    const { addressLines, regionCode } = req.body || {};

    if (!Array.isArray(addressLines) || addressLines.length === 0) {
      return res.status(400).json({ error: "addressLines must be a non-empty array." });
    }

    const cleanedLines = addressLines
      .map(v => String(v).trim())
      .filter(Boolean)
      .slice(0, 5);

    if (!cleanedLines.length) {
      return res.status(400).json({ error: "Enter an address." });
    }

    const response = await fetch(
      `https://addressvalidation.googleapis.com/v1:validateAddress?key=${encodeURIComponent(GOOGLE_KEY)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          address: {
            addressLines: cleanedLines,
            ...(regionCode ? { regionCode: String(regionCode).trim().toUpperCase() } : {})
          }
        })
      }
    );

    const data = await response.json();

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message || "Google Address Validation request failed.",
        google: data
      });
    }

    const result = data.result || {};
    const verdict = result.verdict || {};
    const address = result.address || {};
    const geocode = result.geocode || {};
    const location = geocode.location || {};

    res.json({
      verdict,
      formattedAddress: address.formattedAddress || null,
      postalAddress: address.postalAddress || null,
      location: {
        latitude: typeof location.latitude === "number" ? location.latitude : null,
        longitude: typeof location.longitude === "number" ? location.longitude : null
      },
      placeId: geocode.placeId || null,
      raw: data
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Server error while validating the address." });
  }
});

app.post("/api/submissions", (req, res) => {
  try {
    const {
      addressInput,
      formattedAddress,
      latitude,
      longitude,
      placeId,
      validationStatus,
      raw
    } = req.body || {};

    if (!addressInput || !formattedAddress) {
      return res.status(400).json({ error: "A validated address is required." });
    }

    const stmt = db.prepare(`
      INSERT INTO submissions
      (address_input, formatted_address, latitude, longitude, place_id, validation_status, raw_json)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    const info = stmt.run(
      JSON.stringify(addressInput),
      formattedAddress,
      Number.isFinite(latitude) ? latitude : null,
      Number.isFinite(longitude) ? longitude : null,
      placeId || null,
      validationStatus || null,
      raw ? JSON.stringify(raw) : null
    );

    res.status(201).json({ id: info.lastInsertRowid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Could not save submission." });
  }
});

app.get("/api/submissions", requireAdmin, (req, res) => {
  const rows = db.prepare(`
    SELECT id, submitted_at, address_input, formatted_address,
           latitude, longitude, place_id, validation_status
    FROM submissions
    ORDER BY id DESC
  `).all();

  res.json(rows);
});

app.listen(PORT, () => {
  console.log(`Address Map App running at http://localhost:${PORT}`);
});
