let map;
let marker;
let lastValidation = null;

const form = document.getElementById("addressForm");
const message = document.getElementById("message");
const result = document.getElementById("result");
const formatted = document.getElementById("formatted");
const coordinates = document.getElementById("coordinates");
const placeId = document.getElementById("placeId");
const mapsLink = document.getElementById("mapsLink");
const saveButton = document.getElementById("saveButton");

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  message.textContent = "Validating...";
  result.classList.add("hidden");

  const addressLines = [
    document.getElementById("address").value,
    document.getElementById("city").value
  ].filter(Boolean);

  const regionCode = document.getElementById("country").value.trim();

  try {
    const response = await fetch("/api/validate", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        addressLines,
        regionCode
      })
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Validation failed");
    }

    lastValidation = {
      addressInput: addressLines,
      formattedAddress: data.formattedAddress,
      latitude: data.location.latitude,
      longitude: data.location.longitude,
      placeId: data.placeId,
      validationStatus: JSON.stringify(data.verdict || {}),
      raw: data.raw
    };

    formatted.textContent =
      data.formattedAddress || "No formatted address returned.";

    coordinates.textContent =
      data.location.latitude != null
        ? `Coordinates: ${data.location.latitude}, ${data.location.longitude}`
        : "No coordinates returned.";

    placeId.textContent =
      data.placeId ? `Place ID: ${data.placeId}` : "No Place ID returned.";

    if (
      data.location.latitude != null &&
      data.location.longitude != null
    ) {
      const position = {
        lat: data.location.latitude,
        lng: data.location.longitude
      };

      if (!map) {
        map = new google.maps.Map(document.getElementById("map"), {
          center: position,
          zoom: 18
        });
      } else {
        map.setCenter(position);
        map.setZoom(18);
      }

      if (marker) marker.setMap(null);

      marker = new google.maps.Marker({
        map,
        position,
        title: data.formattedAddress || "Validated address"
      });

      mapsLink.href =
        `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
          `${position.lat},${position.lng}`
        )}`;
    }

    result.classList.remove("hidden");
    message.textContent = "Address validation completed.";
  } catch (error) {
    message.textContent = error.message;
  }
});

saveButton.addEventListener("click", async () => {
  if (!lastValidation) return;

  message.textContent = "Saving...";

  try {
    const response = await fetch("/api/submissions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(lastValidation)
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Could not save.");
    }

    message.textContent = `Saved submission #${data.id}.`;
  } catch (error) {
    message.textContent = error.message;
  }
});

async function loadGoogleMaps() {
  const response = await fetch("/api/config");
  const config = await response.json();

  if (!config.mapsBrowserKey) {
    message.textContent =
      "Google Maps browser API key is not configured.";
    return;
  }

  const script = document.createElement("script");

  script.src =
    "https://maps.googleapis.com/maps/api/js" +
    `?key=${encodeURIComponent(config.mapsBrowserKey)}`;

  script.async = true;
  script.defer = true;

  script.onload = () => {
    if (lastValidation) return;
  };

  document.head.appendChild(script);
}

loadGoogleMaps();
